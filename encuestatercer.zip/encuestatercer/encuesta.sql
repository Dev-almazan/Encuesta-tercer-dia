
CREATE TABLE `encuesta` (
  `idEncuesta` int(10) UNSIGNED NOT NULL,
  `correo` varchar(100) NOT NULL,
  `paterno` varchar(50) NOT NULL,
  `materno` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `nosap` varchar(15) DEFAULT NULL,
  `nombreCurso` varchar(100) NOT NULL,
  `numeroClase` smallint(5) UNSIGNED NOT NULL,
  `p1_metricas` tinyint(1) NOT NULL,
  `p2_cuaderno` tinyint(1) NOT NULL,
  `p3_dudas` varchar(30) NOT NULL,
  `p4_funciones` varchar(30) NOT NULL,
  `comentario` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  ADD PRIMARY KEY (`idEncuesta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  MODIFY `idEncuesta` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
