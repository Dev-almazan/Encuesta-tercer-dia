
  <?php
    $conexion = mysqli_connect("localhost","root","","lmssf");
    $correo = $_POST['correo'];
    $apPat = $_POST['apPat'];
    $apMat = $_POST['apMat'];
    $nomb = $_POST['nomb'];
    $sap = $_POST['sap'];
    $curso = $_POST['curso'];
    $clase = $_POST['clase'];
    if($_POST['preg1'] == 's')
        $preg1 = true;
    else
        $preg1 = false;
    if($_POST['preg2'] == 's')
        $preg2 = true;
    else
        $preg2 = false;
    $preg3 = $_POST['preg3'];
    $preg4 = $_POST['preg4'];
    $comentario = $_POST['comentario'];
    $qry = "INSERT INTO encuesta(correo,paterno,materno,nombre,nosap,nombreCurso,numeroClase,p1_metricas,p2_cuaderno,p3_dudas,p4_funciones,comentario) VALUES('$correo','$apPat','$apMat','$nomb','$sap','$curso',$clase,$preg1,$preg2,'$preg3','$preg4','$comentario')";
    if(mysqli_query($conexion, $qry)){
        echo '<script>alert("Respuestas guardadas ¡Gracias!")</script>';
        header('Location: ./');
    }
    else
        echo '<script>alert("Error en las respuestas")</script>';
    
    ?>
