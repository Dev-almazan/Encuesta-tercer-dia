
  <?php


        $peticion = $_POST['peticion'];

        if($peticion == "ENC-1")
        {
                                /* 1- Declaramos variables*/

                                $idencuesta = "ENC-".date('YmdHis'); // id de encuesta  

                                $nombre = $_POST['nombre']; 
                                $paterno = $_POST['paterno'];  
                                $materno = $_POST['materno'];
                
                                $evento = $_POST['evento'];
                                $clase = $_POST['clase'];
                                $sap = $_POST['sap'];    
                
                                $preg1 = $_POST['preg1'];
                                $preg2 = $_POST['preg2'];
                                $preg3 = $_POST['preg3'];
                                
                                $preg4 = $_POST['preg4'];
                                $preg5 = $_POST['preg5']; 
                                $preg6 = $_POST['preg6'];
                                
                                $preg7 = $_POST['preg7'];  
                                $preg8 = $_POST['preg8'];
                                
                                
                
                        /*2- Validamos que los indices no esten vacios*/
                        
                        $vacio = NULL;
                
                                switch($vacio)
                                {
                
                                        case $nombre;
                                        case $paterno;
                                        case $materno;
                                        case $evento;
                                        case $clase;
                                        case $sap;
                                        case $preg1;
                                        case $preg2;
                                        case $preg3;
                                        case $preg4;
                                        case $preg5;
                                        case $preg6;
                                        case $preg7;
                                        case $preg8;
                                        echo 'Favor de completar todos los campos';
                                        exit();
                                        break;
                                }
                
                                //Se valida que los datos tengan el tipo de dato correcto
                                
                                
                                //Validamos que $clase sea numérico
                                if(!is_numeric($clase))
                                {       
                                        echo "El número de clase no puede contener letras ni símbolos";
                                        exit();
                                }
                                //Validamos que $sap sea numérico
                                if(!is_numeric($sap))
                                {       
                                        echo "El número de empleado no puede contener letras ni símbolos";
                                        exit();
                                }
                
                                //Validamos preguntas
                                function validaSiNo($preg, $num)
                                {
                                        if($preg != "si" && $preg != "no")
                                        {
                                                echo "Error en pregunta $num. Refresque la página e intente nuevamente";
                                                exit();
                                        }
                                }
                
                                validaSiNo($preg1, 1);
                                validaSiNo($preg5, 5);
                                validaSiNo($preg6, 6);
                
                                function validaEscala($preg, $num)
                                {
                                        if($preg != "siempre" && $preg != "casi siempre" && $preg != "a veces" && $preg != "nunca")
                                        {
                                                echo "Error en pregunta $num. Refresque la página e intente nuevamente.";
                                                exit();
                                        }
                                }
                
                                validaEscala($preg2, 2);
                                validaEscala($preg3, 3);
                                validaEscala($preg4, 4);
                                validaEscala($preg7, 7);
                                validaEscala($preg8, 8);
                
                                //Si todo esta correcto, enviamos id mensaje
                                echo TRUE ;
                
                        
                                           
        }
        else
        {
                echo "Hubo un error al procesar la solicitud -Favor de contactar al administrador";
                exit;
        }


?>